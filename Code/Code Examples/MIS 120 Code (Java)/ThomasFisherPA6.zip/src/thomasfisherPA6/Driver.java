package thomasfisherPA6;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Driver
{
	/*EXTRAS:
	 * Customized error message for each pre-process loop
	 * Utilization of polymorphism (multiple constructors for one object)
	 * Commented logic for each major step
	 * Utilization of arrayLists
	 * Utilization of a comparator
	 * JavaDocs
	 */
	
	/**
	 * I had to redo all of PA6, I needed to call main in a past version,
	 * I just never took it out 	
	 * @param args
	 * @throws IOException in case the files are not in the system
	 */
	public static void main(String[] args) throws IOException
	{
		newMain();
	}

	/**
	 * This is where the main logic is held
	 * @throws IOException
	 */
	public static void newMain() throws IOException
	{
		// create arrayLists for the master, and all update types
		ArrayList<Movies> updateList = new ArrayList<Movies>();
		ArrayList<Movies> masterList = new ArrayList<Movies>();
		ArrayList<Movies> headerList = new ArrayList<Movies>();
		ArrayList<Movies> trailerList = new ArrayList<Movies>();

		int detailCount = 0;

		// create the updateList, headerList, and trailerList from the
		// update.txt file
		File file = new File("update.txt");
		Scanner scan = new Scanner(file);
		while (scan.hasNextLine())
		{
			while (scan.hasNext())
			{
				String str = scan.nextLine();
				String[] myData = str.split("#");
				if (myData[0].equalsIgnoreCase("H"))
				{
					Movies header = new Movies(myData[0], myData[1], myData[2]);
					headerList.add(0, header);
				} else if (myData[0].equalsIgnoreCase("T"))
				{
					Movies trailer = new Movies(myData[0], myData[1], myData[2], Integer.parseInt(myData[3]),
							Integer.parseInt(myData[4]));
					trailerList.add(0, trailer);
				} else
				{ // It has to be a detail
					Movies updates = new Movies(myData[0], myData[1], Integer.parseInt(myData[2]),
							Integer.parseInt(myData[3]), myData[4], myData[5], Integer.parseInt(myData[6]),
							Boolean.parseBoolean(myData[7]), Integer.parseInt(myData[8]), Integer.parseInt(myData[9]));
					updateList.add(detailCount, updates);
					detailCount++;
				}
			}
		}
		scan.close();


		// create the masterList from master.txt
		File file2 = new File("master.txt");
		Scanner scan2 = new Scanner(file2);
		while (scan2.hasNextLine())
		{
			String str = scan2.nextLine();
			String[] myData = str.split("#");
			Movies master = new Movies(Integer.parseInt(myData[0]), Integer.parseInt(myData[1]), myData[2], myData[3],
					Integer.parseInt(myData[4]), Boolean.parseBoolean(myData[5]), Integer.parseInt(myData[6]),
					Integer.parseInt(myData[7]));
			masterList.add(master);
		}
		scan2.close();

		// below starts the pre-process checks

		// create the current month variable
		Calendar cal = Calendar.getInstance();
		int currentMonth = cal.get(Calendar.MONTH) + 1;
		// get the month from the file
		String fileDateString = headerList.get(0).getFileDate();
		String[] fullDate = fileDateString.split("\\\\");
		int fileMonth = Integer.parseInt(fullDate[0]);

		// add up the total rentals in the details
		int rentSum = 0;
		for (int i = 0; i < updateList.size(); i++)
		{
			rentSum += updateList.get(i).getTotalRentals();
		}

		if (trailerList.get(0).getNumRecords() != detailCount + 2)// if the
																	// number of
																	// records
																	// is not
																	// accurate
		{
			JOptionPane.showMessageDialog(null,
					"The number of records in the trailer does not match the the number" + " of records in the file");
		} else if (!(fileMonth >= currentMonth - 1))// if the file is more than a
													// month old
		{
			JOptionPane.showMessageDialog(null, "The file is more than a month old");
		}

		else if (rentSum != trailerList.get(0).getSumRentals())// if total
																// records is
																// not accurate
		{
			JOptionPane.showMessageDialog(null, "The total rentals in the trailer is not accurate");
		}

		else // the updates have passed all previous checks
		{
			// begin to process the action codes
			for (int x = 0; x < updateList.size(); x++)
			{
				if (updateList.get(x).getActionCode().equalsIgnoreCase("A"))
				{
					masterList.add(updateList.get(x));
				} else if (updateList.get(x).getActionCode().equalsIgnoreCase("C"))
				{
					for (int y = 0; y < masterList.size(); y++)
					{
						if ((masterList.get(y).getBoxID() == updateList.get(x).getBoxID())
								&& (masterList.get(y).getMovieID() == updateList.get(x).getMovieID()))
						// search the master for the boxID and the movieID
						// when they both match, change that index in the master
						{
							masterList.get(y).equals(updateList.get(x));
						}
					}
				} else // it must be d
				{
					for (int y = 0; y < masterList.size(); y++)
					{
						if ((masterList.get(y).getBoxID() == updateList.get(x).getBoxID())
								&& (masterList.get(y).getMovieID() == updateList.get(x).getMovieID()))
						// search the master for the boxID and the movieID
						// when they both match, remove that index from the
						// master
						{
							masterList.remove(y);
						}
					}
				}
			}
		}
		// Print the updated masterList to a file
		PrintWriter pw = new PrintWriter("master.txt");
		for (int i = 0; i < masterList.size(); i++)
		{
			pw.print((masterList.get(i).getBoxID()) + "#");
			pw.print((masterList.get(i).getMovieID()) + "#");
			pw.print((masterList.get(i).getMovieTitle()) + "#");
			pw.print((masterList.get(i).getMovieGenre()) + "#");
			pw.print((masterList.get(i).getReleaseYear()) + "#");
			pw.print((masterList.get(i).isInStock()) + "#");
			pw.print((masterList.get(i).getTotalRentals()) + "#");
			pw.print((masterList.get(i).getRentals30()));
			pw.println("\n");
		}
		pw.close();

		// start of report 1
		
		//create a printwriter object 
		PrintWriter r1 = new PrintWriter("report1.txt");

		// Sort the array by genre, then by rentals in last 30 days
		Collections.sort(masterList, new MoviesComp());
		
		int tempRentals = masterList.get(0).getTotalRentals();
		int tempRevenue = masterList.get(0).getTotalRentals() * 2; // $2 per
																	// rental
		String tempGenre = masterList.get(0).getMovieGenre();
		for (int i = 1; i < masterList.size(); i++)
		{
			if (!(masterList.get(i-1).getMovieGenre().equalsIgnoreCase(masterList.get(i).getMovieGenre())))
			{
				r1.println(tempGenre+": rentals- " + tempRentals + ", revenue-  " + tempRevenue);
				r1.println("");
				r1.println("----");
				r1.println("");
				tempRentals = 0;
				tempRevenue = 0;
				tempGenre = masterList.get(i).getMovieGenre();
			}
			tempRentals += masterList.get(i).getTotalRentals();
			tempRevenue += masterList.get(i).getTotalRentals() * 2;
		}
		r1.close();
		
		//Start of report2
		
		//create a PrintWriter object
		PrintWriter r2 = new PrintWriter ("report2.txt");
		//the masterList should already be sorted by genre and by last30 from the previous report
		
		ArrayList <String> movieTitles = new ArrayList<String>();
		String tempGenre2 = masterList.get(0).getMovieGenre();
		for (int i = 1; i<masterList.size(); i++)
		{
			//the break triggers if the genre doesn't match, or if there are 5 movies
			if ((!(masterList.get(i-1).getMovieGenre().equalsIgnoreCase(masterList.get(i).getMovieGenre()))) || movieTitles.size()==5)
			{
				for (int x = 0; x<movieTitles.size(); x++)
				{
					r2.print(tempGenre2 + " " + movieTitles.get(x).toString());
					r2.println("\n");
				}
				movieTitles.clear();
				tempGenre2 = masterList.get(i).getMovieGenre();
			}
			movieTitles.add(masterList.get(i).getMovieTitle());
			tempRevenue += masterList.get(i).getTotalRentals() * 2;
		}
		r2.close();
	}
	
	
	

	// Sam Rez taught me how to use comparator
	// This sorts the movies by genre, then by highest rentals in 30 days
	public static class MoviesComp implements Comparator<Movies>
	{
		public int compare(Movies m1, Movies m2)
		{
			String genre1 = m1.getMovieGenre();
			String genre2 = m2.getMovieGenre();
			int comp = genre1.compareToIgnoreCase(genre2);
			if (comp <0 )
			{
				return -1;
			} else if (comp == 0) // if the genres are equal, then sort by most
									// rentals in last 30 days
			{
				if (m1.getRentals30() > m2.getRentals30())// if m1 has the
															// higher rentals in
															// 30 days
				{
					return -1;
				} else // m2 has higher rentals in 30 days
				{
					return 1;
				}
			} else
			{
				return 1;
			}
		}
	};
}
