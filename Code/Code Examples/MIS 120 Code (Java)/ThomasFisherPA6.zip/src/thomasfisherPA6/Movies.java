package thomasfisherPA6;

public class Movies
{
	private String recordType;
	private String actionCode;
	private int boxID;
	private int movieID;
	private String movieGenre;
	private String movieTitle;
	private int releaseYear;
	private boolean inStock;
	private int rentals30;
	private String fileName;
	private String fileDate;
	private int totalRentals;
	private int numRecords;
	private int sumRentals;

	// This is a constuctor for the master movie array
	public Movies(int boxID, int movieID, String movieTitle, String movieGenre, int releaseYear, boolean inStock,
			int totalRentals, int rentals30)
	{
		super();
		this.boxID = boxID;
		this.movieID = movieID;
		this.movieGenre = movieGenre;
		this.movieTitle = movieTitle;
		this.releaseYear = releaseYear;
		this.inStock = inStock;
		this.rentals30 = rentals30;
		this.totalRentals = totalRentals;
	}

	// This is a constructor for the detail records
	public Movies(String recordType, String actionCode, int boxID, int movieID, String movieTitle, String movieGenre,
			int releaseYear, boolean inStock, int totalRentals, int rentals30)
	{
		super();
		this.recordType = recordType;
		this.actionCode = actionCode;
		this.boxID = boxID;
		this.movieID = movieID;
		this.movieGenre = movieGenre;
		this.movieTitle = movieTitle;
		this.releaseYear = releaseYear;
		this.inStock = inStock;
		this.rentals30 = rentals30;
		this.totalRentals = totalRentals;
	}

	// This is a constructor for the header record
	public Movies(String recordType, String fileName, String fileDate)
	{
		super();
		this.recordType = recordType;
		this.fileName = fileName;
		this.fileDate = fileDate;
	}

	// This is a constructor for the trailer record
	public Movies(String recordType, String fileName, String fileDate, int numRecords, int sumRentals)
	{
		super();
		this.recordType = recordType;
		this.fileName = fileName;
		this.fileDate = fileDate;
		this.numRecords = numRecords;
		this.sumRentals = sumRentals;
	}

	public String getRecordType()
	{
		return recordType;
	}

	public void setRecordType(String recordType)
	{
		this.recordType = recordType;
	}

	public String getActionCode()
	{
		return actionCode;
	}

	public void setActionCode(String actionCode)
	{
		this.actionCode = actionCode;
	}

	public int getBoxID()
	{
		return boxID;
	}

	public void setBoxID(int boxID)
	{
		this.boxID = boxID;
	}

	public int getMovieID()
	{
		return movieID;
	}

	public void setMovieID(int movieID)
	{
		this.movieID = movieID;
	}

	public String getMovieGenre()
	{
		return movieGenre;
	}

	public void setMovieGenre(String movieGenre)
	{
		this.movieGenre = movieGenre;
	}

	public String getMovieTitle()
	{
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle)
	{
		this.movieTitle = movieTitle;
	}

	public int getReleaseYear()
	{
		return releaseYear;
	}

	public void setReleaseYear(int releaseYear)
	{
		this.releaseYear = releaseYear;
	}

	public boolean isInStock()
	{
		return inStock;
	}

	public void setInStock(boolean inStock)
	{
		this.inStock = inStock;
	}

	public int getRentals30()
	{
		return rentals30;
	}

	public void setRentals30(int rentals30)
	{
		this.rentals30 = rentals30;
	}

	public String getFileName()
	{
		return fileName;
	}

	public void setFileName(String fileName)
	{
		this.fileName = fileName;
	}

	public String getFileDate()
	{
		return fileDate;
	}

	public void setFileDate(String fileDate)
	{
		this.fileDate = fileDate;
	}

	public int getTotalRentals()
	{
		return totalRentals;
	}

	public void setTotalRentals(int totalRentals)
	{
		this.totalRentals = totalRentals;
	}

	public int getNumRecords()
	{
		return numRecords;
	}

	public void setNumRecords(int numRecords)
	{
		this.numRecords = numRecords;
	}

	public int getSumRentals()
	{
		return sumRentals;
	}

	public void setSumRentals(int sumRentals)
	{
		this.sumRentals = sumRentals;
	}

}