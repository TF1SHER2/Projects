﻿namespace PokeDex
{
    partial class PokeDex
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.txtWeight = new System.Windows.Forms.TextBox();
            this.txtType = new System.Windows.Forms.TextBox();
            this.txtHP = new System.Windows.Forms.TextBox();
            this.lblNewPokemon = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lblHP = new System.Windows.Forms.Label();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblDisplay = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblCount = new System.Windows.Forms.Label();
            this.sortBy = new System.Windows.Forms.GroupBox();
            this.btnHP = new System.Windows.Forms.RadioButton();
            this.btnHeight = new System.Windows.Forms.RadioButton();
            this.btnWeight = new System.Windows.Forms.RadioButton();
            this.btnType = new System.Windows.Forms.RadioButton();
            this.btnName = new System.Windows.Forms.RadioButton();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.sortBy.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(223, 60);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(323, 30);
            this.txtName.TabIndex = 1;
            // 
            // txtDisplay
            // 
            this.txtDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDisplay.Location = new System.Drawing.Point(11, 290);
            this.txtDisplay.Multiline = true;
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.ReadOnly = true;
            this.txtDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDisplay.Size = new System.Drawing.Size(983, 300);
            this.txtDisplay.TabIndex = 1;
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(223, 202);
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(323, 30);
            this.txtHeight.TabIndex = 5;
            // 
            // txtWeight
            // 
            this.txtWeight.Location = new System.Drawing.Point(223, 166);
            this.txtWeight.Name = "txtWeight";
            this.txtWeight.Size = new System.Drawing.Size(323, 30);
            this.txtWeight.TabIndex = 4;
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(223, 131);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(323, 30);
            this.txtType.TabIndex = 3;
            // 
            // txtHP
            // 
            this.txtHP.Location = new System.Drawing.Point(223, 95);
            this.txtHP.Name = "txtHP";
            this.txtHP.Size = new System.Drawing.Size(323, 30);
            this.txtHP.TabIndex = 2;
            // 
            // lblNewPokemon
            // 
            this.lblNewPokemon.AutoSize = true;
            this.lblNewPokemon.Location = new System.Drawing.Point(7, 12);
            this.lblNewPokemon.Name = "lblNewPokemon";
            this.lblNewPokemon.Size = new System.Drawing.Size(131, 24);
            this.lblNewPokemon.TabIndex = 6;
            this.lblNewPokemon.Text = "New Pokemon";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(44, 62);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(64, 24);
            this.lblName.TabIndex = 7;
            this.lblName.Text = "Name:";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(44, 133);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(55, 24);
            this.lblType.TabIndex = 8;
            this.lblType.Text = "Type:";
            // 
            // lblHP
            // 
            this.lblHP.AutoSize = true;
            this.lblHP.Location = new System.Drawing.Point(44, 98);
            this.lblHP.Name = "lblHP";
            this.lblHP.Size = new System.Drawing.Size(46, 24);
            this.lblHP.TabIndex = 9;
            this.lblHP.Text = "HP:";
            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.Location = new System.Drawing.Point(44, 169);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(77, 24);
            this.lblWeight.TabIndex = 10;
            this.lblWeight.Text = "Weight:";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(44, 204);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(74, 24);
            this.lblHeight.TabIndex = 11;
            this.lblHeight.Text = "Height:";
            // 
            // lblDisplay
            // 
            this.lblDisplay.AutoSize = true;
            this.lblDisplay.Location = new System.Drawing.Point(12, 263);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(75, 24);
            this.lblDisplay.TabIndex = 13;
            this.lblDisplay.Text = "Display";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(408, 247);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(138, 37);
            this.btnAdd.TabIndex = 15;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(848, 12);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(152, 24);
            this.lblCount.TabIndex = 21;
            this.lblCount.Text = "0 of 10 Pokemon";
            // 
            // sortBy
            // 
            this.sortBy.Controls.Add(this.btnHP);
            this.sortBy.Controls.Add(this.btnHeight);
            this.sortBy.Controls.Add(this.btnWeight);
            this.sortBy.Controls.Add(this.btnType);
            this.sortBy.Controls.Add(this.btnName);
            this.sortBy.Location = new System.Drawing.Point(595, 26);
            this.sortBy.Name = "sortBy";
            this.sortBy.Size = new System.Drawing.Size(227, 249);
            this.sortBy.TabIndex = 25;
            this.sortBy.TabStop = false;
            this.sortBy.Text = "Sort By:";
            // 
            // btnHP
            // 
            this.btnHP.AutoSize = true;
            this.btnHP.Location = new System.Drawing.Point(53, 70);
            this.btnHP.Name = "btnHP";
            this.btnHP.Size = new System.Drawing.Size(72, 28);
            this.btnHP.TabIndex = 4;
            this.btnHP.TabStop = true;
            this.btnHP.Text = "HP";
            this.btnHP.UseVisualStyleBackColor = true;
            // 
            // btnHeight
            // 
            this.btnHeight.AutoSize = true;
            this.btnHeight.Location = new System.Drawing.Point(53, 177);
            this.btnHeight.Name = "btnHeight";
            this.btnHeight.Size = new System.Drawing.Size(100, 28);
            this.btnHeight.TabIndex = 3;
            this.btnHeight.TabStop = true;
            this.btnHeight.Text = "Height";
            this.btnHeight.UseVisualStyleBackColor = true;
            // 
            // btnWeight
            // 
            this.btnWeight.AutoSize = true;
            this.btnWeight.Location = new System.Drawing.Point(53, 141);
            this.btnWeight.Name = "btnWeight";
            this.btnWeight.Size = new System.Drawing.Size(103, 28);
            this.btnWeight.TabIndex = 2;
            this.btnWeight.TabStop = true;
            this.btnWeight.Text = "Weight";
            this.btnWeight.UseVisualStyleBackColor = true;
            // 
            // btnType
            // 
            this.btnType.AutoSize = true;
            this.btnType.Location = new System.Drawing.Point(53, 106);
            this.btnType.Name = "btnType";
            this.btnType.Size = new System.Drawing.Size(81, 28);
            this.btnType.TabIndex = 1;
            this.btnType.TabStop = true;
            this.btnType.Text = "Type";
            this.btnType.UseVisualStyleBackColor = true;
            // 
            // btnName
            // 
            this.btnName.AutoSize = true;
            this.btnName.Location = new System.Drawing.Point(53, 35);
            this.btnName.Name = "btnName";
            this.btnName.Size = new System.Drawing.Size(90, 28);
            this.btnName.TabIndex = 0;
            this.btnName.TabStop = true;
            this.btnName.Text = "Name";
            this.btnName.UseVisualStyleBackColor = true;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.Location = new System.Drawing.Point(853, 595);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(142, 43);
            this.btnClose.TabIndex = 26;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnDisplay
            // 
            this.btnDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDisplay.Location = new System.Drawing.Point(648, 595);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(144, 43);
            this.btnDisplay.TabIndex = 27;
            this.btnDisplay.Text = "Display";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // PokeDex
            // 
            this.AcceptButton = this.btnAdd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(1041, 648);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.sortBy);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblDisplay);
            this.Controls.Add(this.lblHeight);
            this.Controls.Add(this.lblWeight);
            this.Controls.Add(this.lblHP);
            this.Controls.Add(this.lblType);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblNewPokemon);
            this.Controls.Add(this.txtHP);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.txtWeight);
            this.Controls.Add(this.txtHeight);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.txtName);
            this.Font = new System.Drawing.Font("Modern No. 20", 7.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "PokeDex";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PokeDex";
            this.sortBy.ResumeLayout(false);
            this.sortBy.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.TextBox txtWeight;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.TextBox txtHP;
        private System.Windows.Forms.Label lblNewPokemon;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblHP;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblDisplay;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.GroupBox sortBy;
        private System.Windows.Forms.RadioButton btnHP;
        private System.Windows.Forms.RadioButton btnHeight;
        private System.Windows.Forms.RadioButton btnWeight;
        private System.Windows.Forms.RadioButton btnType;
        private System.Windows.Forms.RadioButton btnName;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnDisplay;
    }
}

