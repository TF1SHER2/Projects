﻿//Thomas Fisher
//MIS 220-001
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PokeDex
{
    public partial class PokeDex : Form
    {
        public PokeDex()
        {
            InitializeComponent();
        }

        public Pokemon[] pokemon = new Pokemon[10];
        public int counter = 0;
        public enum SortMode
        {
            Name,
            Hp,
            Type,
            Weight,
            Height
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {//todo: exceptions for error handling
                string name = txtName.Text.ToString();
                double hp = Double.Parse(txtHP.Text.ToString());
                string type = txtType.Text.ToString();
                double weight = Double.Parse(txtWeight.Text.ToString());
                double height = Double.Parse(txtHeight.Text.ToString());

                Pokemon p = new global::PokeDex.Pokemon(name, hp, type, weight, height);
                //to prevent array index out of pounds errors
                if (counter <= 9)
                {
                    pokemon[counter] = p;
                    counter++;
                    lblCount.Text = counter + " of 10 Pokemon";
                }
            }
            catch (FormatException)
            {
                double number = 0;
                string name = "";
                //These ifs check which number did not parse if there is an exception thrown
                if (!(Double.TryParse(txtHP.Text, out number)))
                {
                    name = "HP";
                    txtHP.Focus();
                }
                else if (!(Double.TryParse(txtHeight.Text, out number)))
                {
                    name = "Height";
                    txtHeight.Focus();
                }
                else if (!(Double.TryParse(txtWeight.Text, out number)))
                {
                    name = "Weight";
                    txtWeight.Focus();
                }
                MessageBox.Show("The values entered in the " + name + " field are not valid. Please enter only numbers");
            }
            ClearControls();
        }
        private void ClearControls()
        {
            txtHeight.Text = "";
            txtHP.Text = "";
            txtName.Text = "";
            txtType.Text = "";
            txtWeight.Text = "";
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            try {
                txtDisplay.Text = "";
                string sort2String = "";

                int selectionSort = -1;

                if (btnName.Checked == true)
                {
                    selectionSort = (int)SortMode.Name;
                    sort2String = "Name";
                }
                else if (btnHP.Checked == true)
                {
                    selectionSort = (int)SortMode.Hp;
                    sort2String = "HP";
                }
                else if (btnType.Checked == true)
                {
                    selectionSort = (int)SortMode.Type;
                    sort2String = "Type";
                }
                else if (btnWeight.Checked == true)
                {
                    selectionSort = (int)SortMode.Weight;
                    sort2String = "Weight";
                }
                else if (btnHeight.Checked == true)
                {
                    selectionSort = (int)SortMode.Height;
                    sort2String = "Height";
                }
                else
                {
                    MessageBox.Show("Please select a sort method");
                    throw new Exception();
                }
                if (selectionSort == (int)SortMode.Name)
                {
                    for (int i = 0; i < counter; i++)
                    {
                        for (int j = i + 1; j < counter; j++)
                        {
                            if (pokemon[i].getName().CompareTo(pokemon[j].getName()) >= 0)
                            {
                                Pokemon temp = new Pokemon();
                                temp = pokemon[i];
                                pokemon[i] = pokemon[j];
                                pokemon[j] = temp;
                            }
                        }
                    }
                }

                else if (selectionSort == (int)SortMode.Hp)
                {
                    for (int i = 0; i < counter; i++)
                    {
                        for (int j = i + 1; j < counter; j++)
                        {
                            if (pokemon[i].getHP().CompareTo(pokemon[j].getHP()) <= 0)
                            {
                                Pokemon temp = new Pokemon();
                                temp = pokemon[i];
                                pokemon[i] = pokemon[j];
                                pokemon[j] = temp;
                            }
                        }
                    }
                }

                else if (selectionSort == (int)SortMode.Type)
                {
                    for (int i = 0; i < counter; i++)
                    {
                        for (int j = i + 1; j < counter; j++)
                        {
                            if (pokemon[i].getType().CompareTo(pokemon[j].getType()) >= 0)
                            {
                                Pokemon temp = new Pokemon();
                                temp = pokemon[i];
                                pokemon[i] = pokemon[j];
                                pokemon[j] = temp;
                            }
                        }
                    }
                }

                else if (selectionSort == (int)SortMode.Weight)
                {
                    for (int i = 0; i < counter; i++)
                    {
                        for (int j = i + 1; j < counter; j++)
                        {
                            if (pokemon[i].getWeight().CompareTo(pokemon[j].getWeight()) <= 0)
                            {
                                Pokemon temp = new Pokemon();
                                temp = pokemon[i];
                                pokemon[i] = pokemon[j];
                                pokemon[j] = temp;
                            }
                        }
                    }
                }
                else if (selectionSort == (int)SortMode.Height)
                {
                    for (int i = 0; i < counter; i++)
                    {
                        for (int j = i + 1; j < counter; j++)
                        {
                            if (pokemon[i].getHeight().CompareTo(pokemon[j].getHeight()) <= 0)
                            {
                                Pokemon temp = new Pokemon();
                                temp = pokemon[i];
                                pokemon[i] = pokemon[j];
                                pokemon[j] = temp;
                            }
                        }
                    }
                }

                txtDisplay.Text += "~~~~~~PokeDex~~~~~~";
                txtDisplay.Text += Environment.NewLine;
                txtDisplay.Text += "Sorted by: " + sort2String;
                txtDisplay.Text += Environment.NewLine;
                for (int i = 0; i < counter; i++)
                {
                    txtDisplay.Text += Environment.NewLine;
                    txtDisplay.Text += "Pokemon[" + i + "]" + " = " + pokemon[i].getName();
                    txtDisplay.Text += Environment.NewLine;
                    txtDisplay.Text += "HP = " + pokemon[i].getHP();
                    txtDisplay.Text += Environment.NewLine;
                    txtDisplay.Text += "Type = " + pokemon[i].getType();
                    txtDisplay.Text += Environment.NewLine;
                    txtDisplay.Text += "Weight = " + pokemon[i].getWeight();
                    txtDisplay.Text += Environment.NewLine;
                    txtDisplay.Text += "Height = " + pokemon[i].getHeight();
                    txtDisplay.Text += Environment.NewLine;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.StackTrace);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
    public class Pokemon
    {
        private string name;
        private double HP1;
        private double weight;
        private double height;
        private string type;

        public Pokemon()
        {


        }

        public Pokemon(string name, double HP1, string type, double weight, double height)
        {
            this.name = name;
            this.HP1 = HP1;
            this.weight = weight;
            this.height = height;
            this.type = type;
        }
        //todo: check getters and setters, not sure if correct
        public double getHP()
        {       
                return HP1;           
        }

        public string getName()
        {
                return name;
        }

        public double getWeight()
        {
                return weight;
        }

        public double getHeight()
        {
                return height;           
        }

        public string getType() {
                return type;
        }
    }
}
