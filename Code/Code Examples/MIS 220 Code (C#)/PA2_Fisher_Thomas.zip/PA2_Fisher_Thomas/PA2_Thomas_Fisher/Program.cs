﻿//Thomas Fisher MIS220-001

//extras: user validation


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PA2_Fisher_Thomas
{
    class Program
    {
        public static int pScore = 0;
        public static int cScore = 0;
        public static string pName = "";
        public static int p1Score = 0;
        public static int p2Score = 0;
        public static int numGames = 0;
        enum gameMode { SinglePlayer, TwoPlayer }
        enum userChoice { Rock, Paper, Scissors, Lizard, Spock }

        static void Main(string[] args)
        {
            newMain();
        }

        public static void newMain()
        {
            Console.WriteLine("Enter your name: ");
            pName = Console.ReadLine();
            Console.WriteLine("Do you want to play single player, or two player? (Type 1 or 2)");
            try
            {
                int gameMode = int.Parse(Console.ReadLine());


                if (gameMode == 1)
                {
                    singlePlayer();
                }
                else if (gameMode == 2)
                {
                    twoPlayer();
                }
                else
                {
                    Console.WriteLine("Please enter a '1' or a '2'");
                    newMain();
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Please enter a '1' or a '2'");
                newMain();
            }
    }

        public static void singlePlayer()
        {
            Console.WriteLine("Enter the computer's name: ");
            string cName = Console.ReadLine();
            Console.WriteLine("Type your selection: (Paper, Rock, Scissors, Lizard, or Spock)");
            string pChoice = Console.ReadLine();

            //generate the computer's choice and convert it to a useable string
            Random r = new Random();
            int compNum = r.Next(1, 5);
            string compChoice = "";
            if (compNum == 1)
            {
                compChoice = "Paper";
            }
            else if (compNum ==  2)
            {
                compChoice = "Rock";
            }
            else if (compNum == 3)
            {
                compChoice = "Scissors";
            }
            else if (compNum == 4)
            {
                compChoice = "Lizard";
            }
            else //compChoice == 5
            {
                compChoice = "Spock";
            }
            Console.Clear();
            if (cName.Equals("HAL 9000", StringComparison.InvariantCultureIgnoreCase))
            {
                if (pChoice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase))
                {
                    compChoice = "Lizard";
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nLizard eats Paper" + "\n" + cName + " Wins!");
                    cScore++;
                }
                
                else if (pChoice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase))
                {
                    compChoice = "Spock";
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nSpock vaporizes Rock" + "\n" + cName + " Wins!");
                    cScore++;
                }

                else if (pChoice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase))
                {
                    compChoice = "Spock";
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nSpock smashes Scissors" + "\n" + cName + " Wins!");
                    cScore++;
                }

                else if (pChoice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase))
                {
                    compChoice = "Scissors";
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nScissors decapitates Lizard" + "\n" + cName + " Wins!");
                    cScore++;
                }

                else if (pChoice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase))
                {
                    compChoice = "Lizard";
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nLizard poisons Spock" + "\n" + cName + " Wins!");
                    cScore++;
                }
                else
                {
                    Console.WriteLine("Please put in Rock, Paper, Scissors, Lizard, or Spock");
                    singlePlayer();
                }
                numGames++;
                Console.WriteLine(pName + ": " + pScore + "\n" + cName + ": " + cScore + "\nNumber of Games: " + numGames);
                menuPrompt();
            }
            else //the computer's name is not HAL 9000
            {
                //******************************************************************
                if (pChoice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Rock"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nPaper Covers Rock" + "\n" + pName + " Wins!");
                    pScore++;
                }
                
                else if (pChoice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Scissors"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nScissors cut Paper" + "\n" + cName + " Wins!");
                    cScore++;
                }

                else if (pChoice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Paper"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nIt's a tie!");
                }

                else if (pChoice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Lizard"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nLizard eats paper" + "\n" + cName + " Wins!");
                    cScore++;
                }
                else if (pChoice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Spock"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nPaper disproves Spock" + "\n" + pName + " Wins!");
                    pScore++;
                }
                //******************************************************************
                else if (pChoice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Paper"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nPaper covers Rock" + "\n" + cName + " Wins!");
                    cScore++;
                }

                else if (pChoice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Rock"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nIt's a tie!");
                }

                else if (pChoice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Scissors"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nRock smashes Scissors" + "\n" + pName + " Wins!");
                    pScore++;
                }

                else if (pChoice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Lizard"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nRock smashes Lizard" + "\n" + pName + " Wins!");
                    pScore++;
                }

                else if (pChoice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Spock"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nSpock vaporizes Rock" + "\n" + cName + " Wins!");
                    cScore++;
                }
                //******************************************************************
                else if (pChoice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Paper"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nScissors cuts Paper" + "\n" + pName + " Wins!");
                    pScore++;
                }

                else if (pChoice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Rock"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nRock smashes Scissors" + "\n" + cName + " Wins!");
                    cScore++;
                }

                else if (pChoice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Scissors"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nIt's a Tie!");
                }

                else if (pChoice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Lizard"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nScissors decapitates Lizard" + "\n" + pName + " Wins!");
                    pScore++;
                }

                else if (pChoice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Spock"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nSpock smashes Scissors" + "\n" + cName + " Wins!");
                    cScore++;
                }
                //******************************************************************
                else if (pChoice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Paper"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nLizard eats Paper" + "\n" + pName + " Wins!");
                    pScore++;
                }

                else if (pChoice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Rock"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nRock crushes Lizard" + "\n" + cName + " Wins!");
                    cScore++;
                }

                else if (pChoice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Scissors"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nScissors decapitates Lizard" + "\n" + cName + " Wins!");
                    cScore++;
                }

                else if (pChoice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Lizard"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nIt's a Tie!");
                }

                else if (pChoice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Spock"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nLizard poisons Spock" + "\n" + pName + " Wins!");
                    pScore++;
                }
                //******************************************************************
                else if (pChoice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Rock"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nSpock vaporizes Rock" + "\n" + pName + " Wins!");
                    pScore++;
                }

                else if (pChoice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Paper"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nPaper disproves Spock" + "\n" + cName + " Wins!");
                    cScore++;
                }

                else if (pChoice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Scissors"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nSpock smashes Scissors" + "\n" + pName + " Wins!");
                    pScore++;
                }

                else if (pChoice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Lizard"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nLizard poisons Spock" + "\n" + cName + " Wins!");
                    cScore++;
                }

                else if (pChoice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase) && compChoice.Equals("Spock"))
                {
                    Console.WriteLine(pName + ": " + pChoice + "\n" + cName + ": " + compChoice + "\nIt's a Tie!");
                }

                else //the user didn't put in a correct value
                {
                    Console.WriteLine("Please put in Rock, Paper, Scissors, Lizard, or Spock");
                    singlePlayer();
                }

            }
            numGames++;
            Console.WriteLine(pName + ": " + pScore + "\n" + cName + ": " + cScore + "\nNumber of Games: " + numGames);
            menuPrompt();
        }

        public static void twoPlayer()
        {
            Console.WriteLine("Enter player one's choice: (Rock, Paper, Scissors, Lizard, or Spock)");
            string p1Choice = Console.ReadLine();

            //this checks that the user entered a valid response

            if (!((p1Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase)) || (p1Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase)) || (p1Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase)) || (p1Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase)) || (p1Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase))))
            {
                Console.WriteLine("Please enter either 'Rock' 'Paper' 'Scissors' 'Lizard' or 'Spock'");
                twoPlayer();
            }

            //this clears the console so that player 2 doesn't see player 1's choice

                Console.Clear();
            Console.WriteLine("Enter player two's name: ");
            string p2Name = Console.ReadLine();
            Console.WriteLine("Enter player two's choice: (Rock, Paper, Scissors, Lizard, or Spock)");
            string p2Choice = Console.ReadLine();

            Console.Clear();

            if (p1Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nPaper Covers Rock" + "\n" + pName + " Wins!");
                p1Score++;
            }

            else if (p1Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nScissors cut Paper" + "\n" + p2Name + " Wins!");
                p2Score++;
            }

            else if (p1Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nIt's a tie!");
            }

            else if (p1Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nLizard eats paper" + "\n" + p2Name + " Wins!");
                p2Score++;
            }
            else if (p1Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nPaper disproves Spock" + "\n" + pName + " Wins!");
                p1Score++;
            }
            //******************************************************************
            else if (p1Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nPaper covers Rock" + "\n" + p2Name + " Wins!");
                p2Score++;
            }

            else if (p1Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nIt's a tie!");
            }

            else if (p1Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nRock smashes Scissors" + "\n" + pName + " Wins!");
                p1Score++;
            }

            else if (p1Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nRock smashes Lizard" + "\n" + pName + " Wins!");
                p1Score++;
            }

            else if (p1Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nSpock vaporizes Rock" + "\n" + p2Name + " Wins!");
                p2Score++;
            }
            //******************************************************************
            else if (p1Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nScissors cuts Paper" + "\n" + pName + " Wins!");
                p1Score++;
            }

            else if (p1Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nRock smashes Scissors" + "\n" + p2Name + " Wins!");
                p2Score++;
            }

            else if (p1Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nIt's a Tie!");
            }

            else if (p1Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nScissors decapitates Lizard" + "\n" + pName + " Wins!");
                p1Score++;
            }

            else if (p1Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nSpock smashes Scissors" + "\n" + p2Name + " Wins!");
                p2Score++;
            }
            //******************************************************************
            else if (p1Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nLizard eats Paper" + "\n" + pName + " Wins!");
                p1Score++;
            }

            else if (p1Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nRock crushes Lizard" + "\n" + p2Name + " Wins!");
                p2Score++;
            }

            else if (p1Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nScissors decapitates Lizard" + "\n" + p2Name + " Wins!");
                p2Score++;
            }

            else if (p1Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nIt's a Tie!");
            }

            else if (p1Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nLizard poisons Spock" + "\n" + pName + " Wins!");
                p1Score++;
            }
            //******************************************************************
            else if (p1Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Rock", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nSpock vaporizes Rock" + "\n" + pName + " Wins!");
                p1Score++;
            }

            else if (p1Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Paper", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nPaper disproves Spock" + "\n" + p2Name + " Wins!");
                p2Score++;
            }

            else if (p1Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Scissors", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nSpock smashes Scissors" + "\n" + pName + " Wins!");
                p1Score++;
            }

            else if (p1Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Lizard", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nLizard poisons Spock" + "\n" + p2Name + " Wins!");
                p2Score++;
            }

            else if (p1Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase) && p2Choice.Equals("Spock", StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine(pName + ": " + p1Choice + "\n" + p2Name + ": " + p2Choice + "\nIt's a Tie!");
            }

            else //player 2 didn't put in a correct value
            {
                Console.WriteLine("Please put in Rock, Paper, Scissors, Lizard, or Spock");
                twoPlayer();
            }
            numGames++;
            Console.WriteLine(pName + ": " + p1Score + "\n" + p2Name + ": " + p2Score + "\nNumber of Games: " + numGames);
            menuPrompt();
        }
        public static void menuPrompt()
        {
            Console.WriteLine("What do you want to do? \nType 'P1' to play single player, 'P2' to play two player,'C' to clear score, \n'G' to clear number of games played, and 'E' to exit");
            string playAgain = Console.ReadLine();
            if (playAgain.Equals("P1", StringComparison.InvariantCultureIgnoreCase))
            {
                singlePlayer();
            }
            else if (playAgain.Equals("P2", StringComparison.InvariantCultureIgnoreCase))
            {
                twoPlayer();
            }
            else if (playAgain.Equals("E", StringComparison.InvariantCultureIgnoreCase))
            {
                Environment.Exit(0);
            }
            else if (playAgain.Equals("C", StringComparison.InvariantCultureIgnoreCase))
            {
                pScore = 0;
                cScore = 0;
                Console.WriteLine("The Score has now been cleared");
                menuPrompt();
            }
            else if (playAgain.Equals("G", StringComparison.InvariantCultureIgnoreCase))
            {
                numGames = 0;
                Console.WriteLine("The number of games has been cleared");
                menuPrompt();
            }
            else
            {
                Console.WriteLine("Please enter a valid response");
                menuPrompt();
            }
        }
    }
}
