import java.util.Random;

public class SlotMachine
{
	public static String slotsSlots()
	{
		String[] game1 =
		{ "Elephant", "Computer", "Football", "Resume", "Capstone", "Crimson" };
		Random r = new Random();
		String slot = game1[r.nextInt(6)];
		return slot;
	}
}
