import javax.swing.JOptionPane;

public class Player
{
	
	public static String userNameCreation()
	{
		String userName = JOptionPane.showInputDialog("Enter Your Name");
		while ((userName.equals("") || (userName.equals(" "))))
		{
			userName = JOptionPane.showInputDialog("Enter Your Name");
		}
		return userName;
	}

	private static double gil;

	public static double getGil()
	{
		return gil;
	}

	public static void setGil(double d)
	{
		Player.gil = d;
	}

}
