import java.io.FileNotFoundException;
import javax.swing.JOptionPane;

public class Roulette
{
	public static void rouletteGame() throws FileNotFoundException
	{
		try
		{
			int playAgain;
			JOptionPane.showMessageDialog(null,
					"Start off by entering a portion of your gil to risk. \nThen select a color. \nIf the color selected is the color the ball lands in, the amount of risked gil is doubled. \nThe Pocket Colors are as follows: \n1-10, and 19-28, the odd pockets are red and even black \n11-18, and 29-36 the odd numbered pockets are black and even red");
			;
			do
			{
				JOptionPane.showMessageDialog(null, "Your total amount of gil is " + Player.getGil());

				String riskedGilString = JOptionPane
						.showInputDialog("Please enter the number value of the gil you wish to risk");
				double riskedGil = Double.parseDouble(riskedGilString);
				double remainingGil = Player.getGil() - riskedGil;
				if (remainingGil >= 0)
				{
					JOptionPane.showMessageDialog(null, "You are now playing Roulette, \nyou have risked " + riskedGil
							+ "\nand you have " + remainingGil + " left");
					
					Object[] items =
					{ "Red", "Black" };
					int pocketChoice;
					pocketChoice = JOptionPane.showOptionDialog(null, "Please select a pocket color", " ",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, items, items[0]);
					if (pocketChoice == JOptionPane.YES_OPTION)
					{
						if (RouletteWheel.rouletteSpin() % 2 == 1 && ((RouletteWheel.rouletteSpin() >= 1 && RouletteWheel.rouletteSpin() <= 10) || (RouletteWheel.rouletteSpin() >= 19 && RouletteWheel.rouletteSpin() <= 28)))
						{
							Player.setGil(Player.getGil() + (riskedGil * 2));
							JOptionPane.showMessageDialog(null, RouletteWheel.rouletteSpin() + "\nThe ball landed on a red pocket!"
									+ "\nYou now have " + Player.getGil() + " gil");
						} else if (RouletteWheel.rouletteSpin() % 2 == 0
								&& ((RouletteWheel.rouletteSpin() >= 11 && RouletteWheel.rouletteSpin() <= 18) || (RouletteWheel.rouletteSpin() >= 29 && RouletteWheel.rouletteSpin() <= 36)))
						{
							Player.setGil(Player.getGil() + (riskedGil * 2));
							JOptionPane.showMessageDialog(null, RouletteWheel.rouletteSpin() + "\nThe ball landed on a red pocket!"
									+ "\nYou now have " + Player.getGil() + " gil");
						} else
						{
							Player.setGil(Player.getGil() - riskedGil);
							JOptionPane.showMessageDialog(null, RouletteWheel.rouletteSpin() + "\nSorry, the ball landed on a black pocket"
									+ "\nYou now have " + Player.getGil() + " gil");
						}
					} else if (pocketChoice == JOptionPane.NO_OPTION)
					{
						if (RouletteWheel.rouletteSpin() % 2 == 1 && ((RouletteWheel.rouletteSpin() >= 11 && RouletteWheel.rouletteSpin() <= 18) || (RouletteWheel.rouletteSpin() >= 29 && RouletteWheel.rouletteSpin() <= 36)))
						{
							Player.setGil(Player.getGil() + (riskedGil * 2));
							JOptionPane.showMessageDialog(null, RouletteWheel.rouletteSpin() + "\nThe ball landed on a black pocket!"
									+ "\nYou now have " + Player.getGil() + " gil");
						} else if (RouletteWheel.rouletteSpin() % 2 == 0
								&& ((RouletteWheel.rouletteSpin() >= 1 && RouletteWheel.rouletteSpin() <= 10) || (RouletteWheel.rouletteSpin() >= 19 && RouletteWheel.rouletteSpin() <= 28)))
						{
							Player.setGil(Player.getGil() + (riskedGil * 2));
							JOptionPane.showMessageDialog(null, RouletteWheel.rouletteSpin() + "\nThe ball landed on a black pocket!"
									+ "\nYou now have " + Player.getGil() + " gil");
						} else
						{
							Player.setGil(Player.getGil() - riskedGil);
							JOptionPane.showMessageDialog(null, RouletteWheel.rouletteSpin() + "\nSorry, the ball landed on a red pocket"
									+ "\nYou now have " + Player.getGil() + " gil");
						}
					}
					else
					{
						System.exit(0);
					}
				} else
				{
					JOptionPane.showMessageDialog(null, "You cannot risk more gil than you have");
					rouletteGame();
				}
				Menu.save();
				if (Player.getGil() >= 1000 || Player.getGil() == 0)
				{
					Menu.winLoss();
				}
				Object[] items =
				{ "Play Again", "Main Menu" };
				playAgain = JOptionPane.showOptionDialog(null, "Please Select either Play Again, or Main Menu", " ",
						JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, items, items[0]);
				if (playAgain == JOptionPane.NO_OPTION)
				{
					Menu.menuMethod();
				} else if (playAgain == JOptionPane.CANCEL_OPTION)
				{
					System.exit(0);
				}
			} while (playAgain == JOptionPane.YES_OPTION);
			Menu.menuMethod();
		} catch (NumberFormatException e)
		{
			JOptionPane.showMessageDialog(null, "Next time, enter a number...");
			rouletteGame();
		}
	}

}
