import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class Menu
{
	public static void main(String[] args) throws FileNotFoundException
	{
		menuMethod();
	}

	public static void menuMethod() throws FileNotFoundException
	{
		File f = new File("gilAmount.txt");
		if (f.exists())
			load();
		else
			newGame();
		JOptionPane.showMessageDialog(null,
				"Welcome to Jolly JackPot Land, " + Player.userNameCreation() + "!" + "\nYou start each new game with 500 gil, \nTo pay you rent, you need 1000. \nYou can aquire more gil by playing Slots, Dice, or Roulette.");
		// Mathew Young showed me how the OptionDialog box works in java
		
		Object[] items =
		{ "New Game", "Continue" };
		int fileChoice = JOptionPane.showOptionDialog(null,
				"Do you want to play a new game, or continue your previous one? \n(If you previously won, your gil amount has been reset to 500)",
				"Start Menu", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, items, items[0]);
		if (fileChoice == JOptionPane.YES_OPTION)
		{
			newGame();
		} else if (fileChoice == JOptionPane.NO_OPTION)
		{
			JOptionPane.showMessageDialog(null, "You are now starting with " + Player.getGil() + " gil");
			Continue();
		} else
		{
			System.exit(0);
		}
	}

	public static void save() throws FileNotFoundException
	{
		PrintWriter gilAmount = new PrintWriter("gilAmount.txt");
		gilAmount.print(Player.getGil());
		gilAmount.close();

	}

	public static void load() throws FileNotFoundException
	{
		File newGilAmount = new File("gilAmount.txt");
		Scanner x = new Scanner(newGilAmount);
		double gil;
		gil = x.nextDouble();
		x.close();
		Player.setGil(gil);
	}

	public static void newGame() throws FileNotFoundException
	{
		Player.setGil(500);
		Object[] items =
		{ "Slots", "Dice", "Roulette" };
		String gameChoice = (String) JOptionPane.showInputDialog(null, "Do you want to play Slots, Dice, or Roulette?",
				" ", JOptionPane.QUESTION_MESSAGE, null, items, items[0]);
		if (gameChoice.equals("Slots"))
		{
			SlotGame.slots();
		} else if (gameChoice.equals("Dice"))
		{
			DieGame.playDice();
			;
		} else if (gameChoice.equals("Roulette"))
		{
			Roulette.rouletteGame();
			;
		} else
			System.exit(0);

	}

	public static void Continue() throws FileNotFoundException
	{
		Object[] items =
		{ "Slots", "Dice", "Roulette" };
		String gameChoice = (String) JOptionPane.showInputDialog(null, "Do you want to play Slots, Dice, or Roulette?",
				" ", JOptionPane.QUESTION_MESSAGE, null, items, items[0]);
		if (gameChoice.equals("Slots"))
		{
			SlotGame.slots();
		} else if (gameChoice.equals("Dice"))
		{
			DieGame.playDice();
		} else if (gameChoice.equals("Roulette"))
		{
			Roulette.rouletteGame();
		} else
			System.exit(0);
	}

	public static void winLoss() throws FileNotFoundException
	{
		double newGilAmount = Player.getGil();
		if (newGilAmount >= 1000)
		{
			JOptionPane.showMessageDialog(null, "You can pay your rent!");
			save();
			menuMethod();
		} else if (newGilAmount <= 0)
		{
			JOptionPane.showMessageDialog(null, "You're homeless now...");
			save();
			menuMethod();
		} else
		{
			Continue();
		}
	}
}