import java.io.FileNotFoundException;
import javax.swing.JOptionPane;

public class SlotGame
{
	public static void slots() throws FileNotFoundException
	{

		try
		{
			JOptionPane.showMessageDialog(null,
					"Start off by risking a portion of your gil. \nIf two of the returned words match, the risked amount of gil is doubled. \nIf all three words match, the risked amount of gil is tripled \nHowever, if no words match, you will lose the risked amount of gil");
			int playAgain;
			do
			{
				JOptionPane.showMessageDialog(null, "Your total amount of gil is " + Player.getGil());
				String riskedGilString = JOptionPane
						.showInputDialog("Please enter the number value of the gil you wish to risk");
				double riskedGil = Double.parseDouble(riskedGilString);
				double remainingGil = Player.getGil() - riskedGil;
				if (remainingGil >= 0)
				{
					JOptionPane.showMessageDialog(null, "You are now playing slots, \nyou have risked " + riskedGil
							+ "\nand you have " + remainingGil + " left");

					String slot1 = SlotMachine.slotsSlots();
					String slot2 = SlotMachine.slotsSlots();
					String slot3 = SlotMachine.slotsSlots();

					String slots = (slot1 + " - " + slot2 + " - " + slot3);
					if (slot1 == slot2)
					{
						Player.setGil(Player.getGil() + (riskedGil * 2));
						JOptionPane.showMessageDialog(null,
								slots + "\nYou Won!" + "\nYou now have " + Player.getGil() + " gil");
					} else if (slot1 == slot3)
					{
						Player.setGil(Player.getGil() + (riskedGil * 2));
						JOptionPane.showMessageDialog(null,
								slots + "\nYou Won!" + "\nYou now have " + Player.getGil() + " gil");
					} else if (slot2 == slot3)
					{
						Player.setGil(Player.getGil() + (riskedGil * 2));
						JOptionPane.showMessageDialog(null,
								slots + "\nYou Won!" + "\nYou now have " + Player.getGil() + " gil");
					} else if (slot1 == slot2 && slot1 == slot3)
					{
						Player.setGil(Player.getGil() + (riskedGil * 2));
						JOptionPane.showMessageDialog(null,
								slots + "\nYou Won!" + "\nYou now have " + Player.getGil() + " gil");
					} else
					{
						Player.setGil(Player.getGil() - riskedGil);
						JOptionPane.showMessageDialog(null,
								slots + "\nSorry, you lost" + "\nYou now have " + Player.getGil() + " gil");
					}
					Menu.save();

				} else
				{
					JOptionPane.showMessageDialog(null, "You cannont risk more gil than you have");
				}
				if (Player.getGil() >= 1000 || Player.getGil() == 0)
				{
					Menu.winLoss();
					break;
				}
				Object[] items =
				{ "Play Again", "Main Menu" };
				playAgain = JOptionPane.showOptionDialog(null, "Please Select either Play Again, or Main Menu", " ",
						JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, items, items[0]);
				if (playAgain == JOptionPane.NO_OPTION)
				{
					Menu.menuMethod();
				} else if (playAgain == JOptionPane.CANCEL_OPTION)
				{
					System.exit(0);
				}
			} while (playAgain == JOptionPane.YES_OPTION);
		} catch (NumberFormatException e)
		{
			/*
			 * This block tells java what to do once the error has been "caught"
			 * it is important to not that this will only catch the
			 * NumberFormatException error not really sure how to make it run
			 * the try code again
			 */
			JOptionPane.showMessageDialog(null, "Next time, enter a number...");
			slots();
		}
	}
}
