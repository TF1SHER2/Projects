import java.io.FileNotFoundException;

import javax.swing.JOptionPane;

public class DieGame
{
	public static void playDice() throws FileNotFoundException
	{
		try
		{
			JOptionPane.showMessageDialog(null,
					"Start off by risking a portion of your gil. \nPick either a high or low range, or an exact number \nSelecting the correct high range (9-12) or low range (2-5), will double your risked amount \nSelecting the correct exact amount will triple the risked amount of gil \nHowever, if you do not select either a correct range, or a correct exact amount, you will lose the amount of risked gil");
			int playAgain;
			do
			{
				JOptionPane.showMessageDialog(null, "Your total amount of gil is " + Player.getGil());

				String riskedGilString = JOptionPane
						.showInputDialog("Please enter the number value of the gil you wish to risk");

				double riskedGil = Double.parseDouble(riskedGilString);
				double remainingGil = Player.getGil() - riskedGil;
				if (remainingGil >= 0)
				{
					JOptionPane.showMessageDialog(null, "You are now playing dice, \nand you have risked " + riskedGil
							+ "\nand you have " + remainingGil + " left");
					// this is the start of the game two code
					int diceAmount;
					diceAmount = Die.getRandomNumber();
					Object[] items =
					{ "Range", "Exact Amount" };
					int ModeSelection = JOptionPane.showOptionDialog(null, "Do you want to play Range, or Exact Amount",
							"Game Mode Selection", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, items,
							items[0]);
					if (ModeSelection == JOptionPane.YES_OPTION)
					{
						Object[] rangeItems =
						{ "High", "Low" };
						int rangeChoice = JOptionPane.showOptionDialog(null, "Select a High or Low range",
								"Range Selection", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null,
								rangeItems, rangeItems[0]);
						if (rangeChoice == JOptionPane.NO_OPTION)
						{
							if (diceAmount >= 2 && diceAmount <= 5)
							{
								Player.setGil(Player.getGil() + (riskedGil * 2));
								JOptionPane.showMessageDialog(null,
										diceAmount + "\nYou Won!" + "\nYou now have " + Player.getGil() + " gil");
							} else
							{
								Player.setGil(Player.getGil() - riskedGil);
								JOptionPane.showMessageDialog(null, diceAmount + "\nSorry, you lost" + "\nYou now have "
										+ Player.getGil() + " gil");
							}
						} else if (rangeChoice == JOptionPane.YES_OPTION)
						{
							if (diceAmount >= 9 && diceAmount <= 12)
							{
								Player.setGil(Player.getGil() + (riskedGil * 2));
								JOptionPane.showMessageDialog(null,
										diceAmount + "\nYou Won!" + "\nYou now have " + Player.getGil() + " gil");
							} else
							{
								Player.setGil(Player.getGil() - riskedGil);
								JOptionPane.showMessageDialog(null, diceAmount + "\nSorry, you lost" + "\nYou now have "
										+ Player.getGil() + " gil");
							}
						} else
						{
							System.exit(0);
						}
					} else if (ModeSelection == JOptionPane.NO_OPTION)
					{
						String inputString = JOptionPane.showInputDialog("Type the integer of your exact amount");
						int input = Integer.parseInt(inputString);
						if (input >= 2 && input <= 12)
							if (diceAmount == input)
							{
								Player.setGil(Player.getGil() + (riskedGil * 2));
								JOptionPane.showMessageDialog(null,
										diceAmount + "\nYou Won!" + "\nYou now have " + Player.getGil() + " gil");
							} else
							{
								Player.setGil(Player.getGil() - riskedGil);
								JOptionPane.showMessageDialog(null, diceAmount + "\nSorry, you lost" + "\nYou now have "
										+ Player.getGil() + " gil");
							}
						else
						{
							JOptionPane.showMessageDialog(null,
									"All possible sums of rolling 2 dice are between 2 and 12 \nPlease enter a number within that range");
							String inputString2 = JOptionPane.showInputDialog("Type the integer of your exact amount");
							int input2 = Integer.parseInt(inputString2);
							if (input2 >= 2 && input2 <= 12)
								if (diceAmount == input2)
								{
									Player.setGil(Player.getGil() + (riskedGil * 2));
									JOptionPane.showMessageDialog(null,
											diceAmount + "\nYou Won!" + "\nYou now have " + Player.getGil() + " gil");
								} else
								{
									Player.setGil(Player.getGil() - riskedGil);
									JOptionPane.showMessageDialog(null, diceAmount + "\nSorry, you lost"
											+ "\nYou now have " + Player.getGil() + " gil");
								}
						}
					} else
					{
						System.exit(0);
					}
				} else
				{
					JOptionPane.showMessageDialog(null, "You cannont risk more gil than you have");
				}
				Menu.save();
				if (Player.getGil() >= 1000 || Player.getGil() == 0)
				{
					Menu.winLoss();
				}
				Object[] items =
				{ "Play Again", "Main Menu" };
				playAgain = JOptionPane.showOptionDialog(null, "Please Select either Play Again, or Main Menu", " ",
						JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, items, items[0]);
				if (playAgain == JOptionPane.NO_OPTION)
				{
					Menu.menuMethod();
				} else if (playAgain == JOptionPane.CANCEL_OPTION)
				{
					System.exit(0);
				}
			} while (playAgain == JOptionPane.YES_OPTION);
			if (playAgain == JOptionPane.NO_OPTION)
			{
				Menu.menuMethod();
			} else
			{
				System.exit(0);
			}
		} catch (NumberFormatException e)
		{
			JOptionPane.showMessageDialog(null, "Next time, enter a number...");
			playDice();
		}

	}

}
