import java.util.Random;

public class Die
{
	public static int getRandomNumber()
	{
		String[] game2 =
		{ "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" };
		Random r = new Random();
		String diceAmountString = game2[r.nextInt(11)];
		int diceAmount = Integer.parseInt(diceAmountString);
		return diceAmount;
	}

}
